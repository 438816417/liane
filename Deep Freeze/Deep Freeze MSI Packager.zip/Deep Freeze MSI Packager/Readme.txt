========================================================================================
DEEP FREEZE MSI PACKAGER README
========================================================================================
WWW.DOWNLOADLY.IR

This readme file details some important information about the Deep Freeze MSI packager 
release that you have just downloaded.

========================================================================================
ABOUT THIS RELEASE
========================================================================================
The Deep Freeze MSI Packager allows you to transform the Deep Freeze Workstation Install
Program (DFWks.exe) executable file into a Windows Installer (.MSI) file format for
deployment with Active Directory. 

========================================================================================
USING THE DEEP FREEZE MSI PACKAGER
========================================================================================
To use the Deep Freeze MSI Packager, follow the steps below.

1) Create a Deep Freeze Workstation Install Program (also known as the Deep Freeze Client
using the Deep Freeze Configuration Administrator, or use an existing file.
2) Once the Deep Freeze Workstation Install Program (also known as the Deep Freeze Client)
has been generated, open the Deep Freeze MSI Packager and browse to the file location.
3) Specify a name and a location for the MSI package to be created.
4) Accept the EULA and click on Generate MSI file. This will save the Deep Freeze
Workstation Install Program (also known as the Deep Freeze Client) to the location as
specified in Step #3.

The generated MSI file can be used for installing Deep Freeze through the Windows Active
Directory environment and through Silent Install (Command Line Interface).

NOTE: This generated MSI file CANNOT be used for uninstalling Deep Freeze from any of
the workstations that have Deep Freeze installed.

========================================================================================
SUPPORT
========================================================================================
Every effort has been made to design this software for ease of use and to be problem
free. If problems are encountered, contact Technical Support at support.faronics.com
========================================================================================
